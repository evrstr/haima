<!DOCTYPE html>
<html lang="en">
@include('luna.layouts._header')
@yield('content')
@include('luna.layouts._script')
@section('js')
@show
</html>
