<script src="/assets/layui/layui.js"></script>
<script src="/assets/luna/js/jquery-3.4.1.min.js"></script>
<script src="/assets/luna/main.js"></script>
<script src="/assets/layui/lay/modules/layer.js"></script>
