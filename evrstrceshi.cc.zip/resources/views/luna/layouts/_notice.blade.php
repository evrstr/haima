<div class="notice layui-hide-xs">
    <p class="tit">{{ __('system.announcement') }}:</p>
    <div class="tips">{!! config('webset.notice') !!}</div>
</div>
