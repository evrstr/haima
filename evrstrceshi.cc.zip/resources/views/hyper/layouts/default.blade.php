@include('hyper.layouts._header')
<div class="container">
    @yield('content')
</div>
@include('hyper.layouts._footer')
@section('tpljs')
@show