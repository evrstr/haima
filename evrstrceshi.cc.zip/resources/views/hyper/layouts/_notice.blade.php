<div class="row">
	<div class="col-12">
        <div class="card">
            <div class="card-body">
            	<h4 class="header-title mb-3">{{ __('hyper.notice_announcement') }}</h4>
                {!! config('webset.notice') !!}
            </div>
        </div>
    </div>
</div>