<?php
/**
 * Date: 2019/1/30
 * Time: 10:26
 */

return [
    'failed' => '用户名和密码不符',
];