<?php

return [
    'choose'                => '选择要剪裁的图片',
    'title'                  => '图片剪裁器',
    'done'                   => '剪裁',
    'origin'                 => '原图',
    'clear'                  => '清空',
];
