<?php

return [
    'choose'                => 'Select Cropper',
    'title'                 => 'Image Cropper',
    'done'                  => 'Crop',
    'origin'                => 'Origin',
    'clear'                 => 'Clear',
];
