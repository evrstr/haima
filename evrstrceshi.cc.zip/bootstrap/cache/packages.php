<?php return array (
  'codingyu/laravel-ueditor' => 
  array (
    'providers' => 
    array (
      0 => 'Codingyu\\LaravelUEditor\\UEditorServiceProvider',
    ),
  ),
  'codingyu/ueditor' => 
  array (
    'providers' => 
    array (
      0 => 'Codingyu\\Ueditor\\UeditorServiceProvider',
    ),
  ),
  'cyd622/laravel-admin-ext-echarts' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\Widgets\\Echarts\\EchartsServiceProvider',
    ),
  ),
  'encore/laravel-admin' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\AdminServiceProvider',
    ),
    'aliases' => 
    array (
      'Admin' => 'Encore\\Admin\\Facades\\Admin',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'hanson/rainbow' => 
  array (
    'providers' => 
    array (
      0 => 'Hanson\\Rainbow\\RainbowServiceProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'james.xue/login-captcha' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\James\\JamesServiceProvider',
    ),
  ),
  'jenssegers/agent' => 
  array (
    'providers' => 
    array (
      0 => 'Jenssegers\\Agent\\AgentServiceProvider',
    ),
    'aliases' => 
    array (
      'Agent' => 'Jenssegers\\Agent\\Facades\\Agent',
    ),
  ),
  'laravel-admin-ext/config' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\Config\\ConfigServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'mews/captcha' => 
  array (
    'providers' => 
    array (
      0 => 'Mews\\Captcha\\CaptchaServiceProvider',
    ),
    'aliases' => 
    array (
      'Captcha' => 'Mews\\Captcha\\Facades\\Captcha',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'simplesoftwareio/simple-qrcode' => 
  array (
    'providers' => 
    array (
      0 => 'SimpleSoftwareIO\\QrCode\\QrCodeServiceProvider',
    ),
    'aliases' => 
    array (
      'QrCode' => 'SimpleSoftwareIO\\QrCode\\Facades\\QrCode',
    ),
  ),
  'xhat/payjs-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Xhat\\Payjs\\PayjsServiceProvider',
    ),
    'aliases' => 
    array (
      'Payjs' => 'Xhat\\Payjs\\Facades\\Payjs',
    ),
  ),
);