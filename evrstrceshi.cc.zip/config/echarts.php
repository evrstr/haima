<?php

return [
    'view' => 'echarts::index',
    'water_mark_text' => 'assimon@独角发卡',
    'theme' => 'shine',
];
