<?php

return [
    'mchid' => '',
    'key'   => '',

    // 此地址一般无需更改
    'api_url' => 'https://payjs.cn/api/',
];
