<div id="container_<?php echo e($domId, false); ?>" style="<?php echo e($style, false); ?>"></div>
<script type="text/javascript">
option_<?php echo e($domId, false); ?> = {
    title: {
        text: '<?php echo e($title, false); ?>',
        subtext: '<?php echo e($subtext, false); ?>',
        x: '4%'
    },
 <?php if($seriesType == 'line' || $seriesType == 'bar'): ?>
    tooltip: {
        trigger: 'axis',
        axisPointer: {
            type: 'cross',
        }
    },
  <?php else: ?>
    tooltip: {},
  <?php endif; ?>
  <?php if($seriesType != 'radar'): ?>
    toolbox: <?php echo $toolbox; ?>,
  <?php else: ?>
    radar: {
        name: {
            textStyle: {
                color: '#fff',
                backgroundColor: '#999',
                borderRadius: 3,
                padding: [5, 5]
            }
        },
        center: ['50%','60%'],
        indicator: <?php echo $indicator; ?>

    },
 <?php endif; ?>
<?php if($seriesType == 'line' || $seriesType == 'bar'): ?>
    legend: {<?php if (! ($showToolbox)): ?>right: '5%'<?php endif; ?>},
<?php else: ?>
    legend: {
     orient: 'vertical',
     left: '5%',
     top:'15%'
    },
 <?php endif; ?>

    grid: {
        right: '4%',
        bottom: '10%',
    },
<?php if($dataSource != 'null'): ?>
    dataset: {
        source: <?php echo $dataSource; ?>

    },
<?php endif; ?>
 <?php if($dataZoom && ($seriesType == 'line' || $seriesType == 'bar')): ?>
    dataZoom: [
        {
            show: true,
            realtime: true,
            start: 0,
            end: 80,
            handleIcon: 'path://M306.1,413c0,2.2-1.8,4-4,4h-59.8c-2.2,0-4-1.8-4-4V200.8c0-2.2,1.8-4,4-4h59.8c2.2,0,4,1.8,4,4V413z',
            handleSize: '120%',
        },
        {
            type: 'inside',
            realtime: true
        }
    ],
<?php endif; ?>
<?php if($seriesType == 'line' || $seriesType == 'bar'): ?>
    xAxis: {
        type: 'category',
        boundaryGap: <?php echo e($boundaryGap, false); ?>,
        <?php if($xAxisRotate): ?>
        axisLabel: {
            interval: 0,
            rotate: <?php echo e($xAxisRotate, false); ?>

        },
        <?php endif; ?>
        axisTick: {
            alignWithLabel: true
        }
    },
    yAxis: {
        splitLine: {
            lineStyle: {
                color: ['red', 'blue','green'],
                opacity: 0.10,
            }
        }
    },
<?php endif; ?>
    series: <?php echo $series; ?>

};

<?php if($waterMarkText): ?>
waterMarkCanvas=drawWaterMark('<?php echo e($waterMarkText, false); ?>');
<?php endif; ?>
echartTheme='<?php echo e($theme, false); ?>';
drawEcharts("container_<?php echo e($domId, false); ?>",option_<?php echo e($domId, false); ?>);
</script><?php /**PATH D:\phpstudy_pro\WWW\evrstrceshi.cc\vendor\cyd622\laravel-admin-ext-echarts\src/../resources/views/index.blade.php ENDPATH**/ ?>