<div class="row">
	<div class="col-12">
        <div class="card">
            <div class="card-body">
            	<h4 class="header-title mb-3"><?php echo e(__('hyper.notice_announcement'), false); ?></h4>
                <?php echo config('webset.notice'); ?>

            </div>
        </div>
    </div>
</div><?php /**PATH D:\phpstudy_pro\WWW\evrstrceshi.cc\resources\views/hyper/layouts/_notice.blade.php ENDPATH**/ ?>