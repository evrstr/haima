<?php $__env->startSection('content'); ?>

    <div class="layui-row">
        <div class="layui-col-md8 layui-col-md-offset2 layui-col-sm12">

            <div class="layui-card cardcon">
                <div class="layui-card-header"><?php echo e(__('system.confirm_order'), false); ?></div>

                <div class="layui-card-body">
                    <div class="product-info">
                        <p style="color: #1E9FFF;font-size: 20px;font-weight: 500; text-align: center" ><?php echo e(__('system.note'), false); ?>：<?php echo e(config('app.order_expire_date'), false); ?> <?php echo e(__('system.prompt_to_cancel_order'), false); ?>！</p>
                    </div>
                    <table class="layui-table" lay-skin="" >
                        <colgroup>
                            <col width="100">
                            <col width="150">
                        </colgroup>
                        <tbody>
                        <tr>
                            <td><?php echo e(__('system.order_number'), false); ?>：</td>
                            <td><?php echo e($order_id, false); ?></td>
                        </tr>
                        <tr>
                            <td><?php echo e(__('system.product_name'), false); ?>：</td>
                            <td>
                                <span class="layui-badge layui-bg-blue">
                                    <?php echo e($pd_name, false); ?>

                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td><?php echo e(__('system.commodity_price'), false); ?>：</td>
                            <td>
                                <span class="layui-badge layui-bg-orange">
                                    <?php echo e($product_price, false); ?>

                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td><?php echo e(__('system.purchase_quantity'), false); ?>：</td>
                            <td>x <?php echo e($buy_amount, false); ?></td>
                        </tr>
                        <?php if(isset($coupon_code)): ?>
                        <tr>
                            <td><?php echo e(__('system.promo_code'), false); ?>：</td>
                            <td><span class="layui-badge layui-bg-orange"><?php echo e($coupon_code, false); ?></span></td>
                        </tr>
                        <tr>
                            <td><?php echo e(__('system.discounted_price'), false); ?>：</td>
                            <td> <span class="layui-badge layui-bg-green"><?php echo e($discount, false); ?></span></td>
                        </tr>
                        <?php endif; ?>
                        <tr>
                            <td><?php echo e(__('system.actual_payment'), false); ?>：</td>
                            <td><span class="layui-badge layui-bg-red"><?php echo e($actual_price, false); ?></span></td>
                        </tr>
                        <tr>
                            <td><?php echo e(__('system.email'), false); ?>：</td>
                            <td><?php echo e($account, false); ?></td>
                        </tr>
                        <?php if($other_ipu): ?>
                        <tr>
                            <td><?php echo e(__('system.order_information'), false); ?>:</td>
                            <td><p><?php echo e($other_ipu, false); ?></p></td>
                        </tr>
                        <?php endif; ?>
                        <tr>
                            <td><?php echo e(__('system.payment_method'), false); ?>：</td>
                            <td><?php echo e(\App\Models\Pays::find($pay_way)->pay_name, false); ?></td>
                        </tr>
                        </tbody>
                    </table>
                    <p class="errpanl" style="text-align: center"><a href="<?php echo e(url(\App\Models\Pays::find($pay_way)->pay_handleroute, ['payway' => $pay_way, 'oid' => $order_id]), false); ?>" class="layui-btn layui-btn-sm"><?php echo e(__('system.pay_immediately'), false); ?></a></p>

                </div>



            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('tpljs'); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layui.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpstudy_pro\WWW\evrstrceshi.cc\resources\views/layui/static_pages/bill.blade.php ENDPATH**/ ?>