<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('luna.layouts._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('luna.layouts._script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('js'); ?>
<?php echo $__env->yieldSection(); ?>
</html>
<?php /**PATH D:\phpstudy_pro\WWW\evrstrceshi.cc\resources\views/luna/layouts/default.blade.php ENDPATH**/ ?>