<div class="<?php echo e($viewClass['form-group'], false); ?>">

    <label class="<?php echo e($viewClass['label'], false); ?> control-label"></label>

    <div class="<?php echo e($viewClass['field'], false); ?>">
        <input type='button' value='<?php echo e($label, false); ?>' class="btn <?php echo e($class, false); ?>" <?php echo $attributes; ?> />
    </div>
</div><?php /**PATH D:\phpstudy_pro\WWW\evrstrceshi.cc\vendor\encore\laravel-admin\src/../resources/views/form/button.blade.php ENDPATH**/ ?>