<?php $__env->startSection('content'); ?>

        <div class="layui-row">
            <div class="layui-col-md8 layui-col-md-offset2 layui-col-xs12">
                <div class="layui-card cardcon">
                    <div class="layui-card-header"><span style="color: red"><?php echo e($title, false); ?>：</span></div>
                    <div class="layui-card-body">
                        <p class="product-info" style="text-align: center">
                            <span class="product-price"><?php echo e($content, false); ?></span>
                        </p>
                        <p class="errpanl" style="text-align: center">
                            <?php if(!$url): ?>
                                <a href="javascript:history.back(-1);"  class="layui-btn layui-btn-sm"><?php echo e(__('system.back_btn'), false); ?></a>
                            <?php else: ?>
                                <a href="<?php echo e($url, false); ?>"  class="layui-btn layui-btn-sm"><?php echo e(__('system.back_btn'), false); ?></a>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layui.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpstudy_pro\WWW\evrstrceshi.cc\resources\views/layui/errors/error.blade.php ENDPATH**/ ?>