<div class="sh-notice">

    <div class="layui-row ">
        <!-- PC -->
        <div class="layui-col-md8 layui-col-md-offset2 layui-col-sm12">
            <div class="layui-card cardcon">
                <div class="layui-card-header"><?php echo e(__('system.announcement'), false); ?>：</div>
                <div class="layui-card-body">
                    <?php echo config('webset.notice'); ?>

                </div>
            </div>
        </div>
    </div>

</div>
<?php /**PATH D:\phpstudy_pro\WWW\evrstrceshi.cc\resources\views/layui/layouts/_notice.blade.php ENDPATH**/ ?>