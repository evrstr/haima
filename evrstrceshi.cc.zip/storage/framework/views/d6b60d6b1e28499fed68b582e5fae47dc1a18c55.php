<?php $__env->startSection('notice'); ?>
    <?php echo $__env->make('hyper.layouts._notice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            
            <h4 class="page-title"><?php echo e(__('hyper.buy_title'), false); ?></h4>
        </div>
    </div>
</div>

    <div class="row">
        <div class="col-md-6">
            <div class="card card-body sp-height">
                <form id="buy-form" action="<?php echo e(url('postOrder'), false); ?>" method="post">
                    <?php echo e(csrf_field(), false); ?>

                    <div class="form-group">
                        
                        <h3>
                            <?php echo e($pd_name, false); ?>

                        </h3>
                    </div>
                    <div class="form-group">
                        <?php if($pd_type == 1): ?>
                            
                            <h4><span class="badge badge-outline-primary"><?php echo e(__('hyper.buy_automatic_delivery'), false); ?></span></h4>
                        <?php else: ?>
                            
                            <h4><span class="badge badge-outline-danger"><?php echo e(__('hyper.buy_charge'), false); ?></span></h4>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <h3>
                            
                        	<span>¥ <?php echo e($actual_price, false); ?></span>
                        	
                            <small><del>¥ <?php echo e($cost_price, false); ?></del></small>
                        </h3>
                    </div>
                    <div class="form-group">
                        <?php if(!empty($wholesale_price) && is_array($wholesale_price)): ?>
                        <div class="alert alert-dark bg-white text-dark mb-0" role="alert">
                                
                             <h5><?php echo e(__('hyper.buy_wholesale_discount'), false); ?>：</h5>
                            <?php $__currentLoopData = $wholesale_price; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ws): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <p><?php echo e(__('hyper.buy_purchase_quantity'), false); ?> <?php echo e($ws['number'], false); ?> <?php echo e(__('hyper.buy_the_above'), false); ?>，<?php echo e(__('hyper.buy_each'), false); ?> <?php echo e($ws['price'], false); ?> 元</span></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                             
                            <label class="col-form-label"><?php echo e(__('hyper.buy_email'), false); ?></label>
                            <input type="hidden" name="pid" value="<?php echo e($id, false); ?>">
                             
                            <input type="email" name="account" class="form-control" placeholder="<?php echo e(__('hyper.buy_input_account'), false); ?>">
                        </div>
                        <div class="form-group col-md-6">
                             
                            <label class="col-form-label"><?php echo e(__('hyper.buy_purchase_quantity'), false); ?></label>
                            <div class="input-group">
                                <input type="number" name="order_number" min="1" value="1" class="form-control mr-1" placeholder="">
                                <div class="input-group-append">
                                     
                                    <span style="line-height:44px"><?php echo e(__('hyper.buy_in_stock'), false); ?>(<?php echo e($in_stock, false); ?>)</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <?php if(config('webset.isopen_searchpwd') == 1): ?>
                        <div class="form-group col-md-6">
                             
                            <label class="col-form-label"><?php echo e(__('hyper.buy_search_password'), false); ?></label>
                             
                            <input type="text" name="search_pwd" value="" class="form-control" placeholder="<?php echo e(__('hyper.buy_input_search_password'), false); ?>">
                        </div>
                        <?php endif; ?>
                        <?php if($isopen_coupon == 1): ?>
                        <div class="form-group col-md-6">
                             
                            <label class="col-form-label"><?php echo e(__('hyper.buy_promo_code'), false); ?></label>
                             
                            <input type="text" name="coupon_code" class="form-control" placeholder="<?php echo e(__('hyper.buy_input_promo_code'), false); ?>">
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php if(!empty($other_ipu) && is_array($other_ipu)): ?>
                        <?php $__currentLoopData = $other_ipu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ipu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group">
                            <label class="col-form-label"><?php echo e($ipu['desc'], false); ?></label>
                            <input type="text" name="<?php echo e($ipu['field'], false); ?>" class="form-control" placeholder="">
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            
                            <label class="col-form-label"><?php echo e(__('hyper.buy_payment_method'), false); ?></label>
                            <select class="form-control" name="payway">
                                <option value="0">请选择支付方式</option>
                                <?php $__currentLoopData = $payways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $way): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($way['id'], false); ?>"><?php echo e($way['pay_name'], false); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php if(config('app.shgeetest')): ?>
                        
                        <div class="form-group col-md-6">
                            
                            <label class="col-form-label">行为验证</label>
                            <?php echo Geetest::render('popup'); ?>

                        </div>
                        <?php endif; ?>
                        <?php if(config('webset.verify_code') == 1): ?>
                        
                        <div class="form-group col-md-6">
                            <label class="col-form-label"><?php echo e(__('hyper.buy_verify_code'), false); ?></label>
                            <div class="input-group">
                                <input type="text" name="verify_img" value="" class="form-control" placeholder="<?php echo e(__('hyper.buy_verify_code'), false); ?>">
                                <div class="input-group-append">
                                    <div class="buy-captcha">
                                        <img class="captcha-img"  src="<?php echo e(captcha_src('buy'), false); ?>" onclick="refresh()" style="cursor: pointer;height: 44px;">
                                    </div>
                                </div>
                            </div>
                            <script>
                                function refresh(){
                                    $('img[class="captcha-img"]').attr('src','<?php echo e(captcha_src('buy'), false); ?>'+Math.random());
                                }
                            </script>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="mt-4 text-center">
                        
                        <button type="submit" class="btn btn-danger" id="submit">
                            <i class="mdi mdi-truck-fast mr-1"></i>
                            <?php echo e(__('hyper.buy_order_now'), false); ?>

                        </button>
                    </div>
                </form>
            </div> <!-- end card-->
        </div>
        <div class="col-md-6">
            <div class="card card-body buy-product xq-height">
                
                <h5 class="card-title"><?php echo e(__('hyper.buy_product_desciption'), false); ?></h5>
                <div class="scrollbar">
                    <?php echo $pd_info; ?>

                </div>
            </div> <!-- end card-->
        </div> <!-- end col-->
    </div>

<div class="modal fade" id="buy_prompt" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                
                <h5 class="modal-title" id="myCenterModalLabel"><?php echo e(__('prompt.purchase_tips'), false); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                <?php echo $buy_prompt; ?>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<div class="modal fade" id="img-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width: none;">
        <img id="img-zoom" style="border-radius: 5px;">
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tpljs'); ?>
<script>
    $(function() {
        var sp_height = $('.sp-height').height(),screen_width = $(window).width();
        if(screen_width > '767') {
            $('.xq-height').height(sp_height);
        }
    });
    $('#submit').click(function(){
    	if($("input[name='account']").val() == ''){
    		$.NotificationApp.send("<?php echo e(__('hyper.buy_warning'), false); ?>","邮箱不能为空！","top-center","rgba(0,0,0,0.2)","info");
    		return false;
    	}
    	if($("input[name='order_number']").val() == 0){
    		$.NotificationApp.send("<?php echo e(__('hyper.buy_warning'), false); ?>","购买数量不能为 0！","bottom-right","rgba(0,0,0,0.2)","info");
    		return false;
    	}
    	if($("input[name='order_number']").val() > <?php echo e($in_stock, false); ?>){
    		$.NotificationApp.send("<?php echo e(__('hyper.buy_warning'), false); ?>","数量不允许大于库存！","bottom-right","rgba(0,0,0,0.2)","info");
    		return false;
    	}
        <?php if(config('webset.isopen_searchpwd') == 1): ?>
        if($("input[name='search_pwd']").val() == 0){
    		$.NotificationApp.send("<?php echo e(__('hyper.buy_warning'), false); ?>","查询密码不能为空！","bottom-right","rgba(0,0,0,0.2)","info");
    		return false;
    	}
        <?php endif; ?>
    	if($("select[name='payway']>option:selected").attr('value') == '0'){
    		$.NotificationApp.send("<?php echo e(__('hyper.buy_warning'), false); ?>","未选择支付方式！","bottom-right","rgba(0,0,0,0.2)","info");
    		return false;
    	}
    	<?php if(config('webset.verify_code') == 1): ?>
    	if($("input[name='verify_img']").val() == ''){
    		$.NotificationApp.send("<?php echo e(__('hyper.buy_warning'), false); ?>","验证码不能为空！","bottom-right","rgba(0,0,0,0.2)","info");
    		return false;
    	}
    	<?php endif; ?>
    });
    <?php if(!empty($buy_prompt)): ?>
    $('#buy_prompt').modal();
    <?php endif; ?>
    $(function() {
        //点击图片放大
        $("#img-zoom").click(function(){
            $('#img-modal').modal("hide");
        });
        $("#img-dialog").click(function(){
            $('#img-modal').modal("hide");
        });
        $(".buy-product img").each(function(i){
            var src = $(this).attr("src");
            $(this).click(function () {
                $("#img-zoom").attr("src", src);
                var oImg = $(this);
                var img = new Image();
                img.src = $(oImg).attr("src");
                var realWidth = img.width;
                var realHeight = img.height;
                var ww = $(window).width();
                var hh = $(window).height();
                $("#img-content").css({"top":0,"left":0,"height":"auto"});
                $("#img-zoom").css({"height":"auto"});
                $("#img-zoom").css({"margin-left":"auto"});
                $("#img-zoom").css({"margin-right":"auto"});
                if((realWidth+20)>ww){
                    $("#img-content").css({"width":"100%"});
                    $("#img-zoom").css({"width":"100%"});
                }else{
                    $("#img-content").css({"width":realWidth+20, "height":realHeight+20});
                    $("#img-zoom").css({"width":realWidth, "height":realHeight});
                }
                if((hh-realHeight-40)>0){
                    $("#img-content").css({"top":(hh-realHeight-40)/2});
                }
                if((ww-realWidth-20)>0){
                    $("#img-content").css({"left":(ww-realWidth-20)/2});
                }
                $('#img-modal').modal();
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('hyper.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpstudy_pro\WWW\evrstrceshi.cc\resources\views/hyper/static_pages/buy.blade.php ENDPATH**/ ?>