<script src="https://cdn.bootcss.com/jquery/2.1.0/jquery.min.js"></script>
<script src="https://static.geetest.com/static/tools/gt.js"></script>
<div id="<?php echo e($captchaid, false); ?>"></div>
<p id="wait-<?php echo e($captchaid, false); ?>" class="show">正在加载验证码...</p>
<?php  use Illuminate\Support\Facades\Config; ?>
<script>
    var geetest = function(url) {
        var handlerEmbed = function(captchaObj) {
            $("#<?php echo e($captchaid, false); ?>").closest('form').submit(function(e) {
                var validate = captchaObj.getValidate();
                if (!validate) {
                    layer.msg('<?php echo e(Config::get('geetest.client_fail_alert'), false); ?>', {
                            icon: 5
                        })
                    e.preventDefault();
                }

            });
            captchaObj.appendTo("#<?php echo e($captchaid, false); ?>");
            captchaObj.onReady(function() {
                $("#wait-<?php echo e($captchaid, false); ?>")[0].className = "hide";
            });
            captchaObj.onSuccess(function () {$('#GeetestCaptcha').attr("placeholder",'<?php echo e(__('system.success_behavior_verification'), false); ?>')})
            if ('<?php echo e($product, false); ?>' == 'popup') {
                //captchaObj.bindOn($('#<?php echo e($captchaid, false); ?>').closest('form').find(':submit'));
                captchaObj.appendTo("#<?php echo e($captchaid, false); ?>");
            }
        };
        $.ajax({
            url: url + "?t=" + (new Date()).getTime(),
            type: "get",
            dataType: "json",
            success: function(data) {
                initGeetest({
                    gt: data.gt,
                    challenge: data.challenge,
                    product: "<?php echo e($product?$product:Config::get('geetest.product', 'float'), false); ?>",
                    offline: !data.success,
                    new_captcha: data.new_captcha,
                    lang: '<?php echo e(Config::get('geetest.lang', 'zh-cn'), false); ?>',
                    http: '<?php echo e(Config::get('geetest.protocol', 'http'), false); ?>' + '://'
                }, handlerEmbed);
            }
        });
    };
    (function() {
        geetest('<?php echo e($url?$url:Config::get('geetest.url', 'geetest'), false); ?>');
    })();
</script>
<style>
    .hide {
        display: none;
    }
    <?php if(config('webset.tpl_sign') == 'hyper'): ?>
    .geetest_holder.geetest_wind {
        width: 100%!important;
        min-width: 100%!important;
    }
    <?php endif; ?>
</style>
<?php /**PATH D:\phpstudy_pro\WWW\evrstrceshi.cc\resources\views/vendor/geetest/geetest.blade.php ENDPATH**/ ?>