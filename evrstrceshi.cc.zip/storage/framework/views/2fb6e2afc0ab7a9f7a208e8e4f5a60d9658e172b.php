<?php $__env->startSection('content'); ?>

    <div class="layui-row">
        <div class="layui-col-md8 layui-col-md-offset2 layui-col-sm12">

            <div class="layui-card cardcon">
                <div class="layui-card-header"><?php echo e(__('system.order_search'), false); ?></div>

                <div class="layui-card-body">
                    <div class="layui-tab">
                        <ul class="layui-tab-title">
                            <li class="layui-this"><?php echo e(__('system.order_search_by_number'), false); ?></li>
                            <li><?php echo e(__('system.order_search_by_email'), false); ?></li>
                            <li><?php echo e(__('system.order_search_by_ie'), false); ?></li>
                        </ul>
                        <div class="layui-tab-content">
                            <div class="product-info">
                                <p style="color: #1E9FFF;font-size: 20px;font-weight: 500; text-align: center" ><?php echo e(__('system.query_tips'), false); ?></p>
                            </div>
                            <!-- 订单号查询 -->
                            <div class="layui-tab-item layui-show">
                                <form class="layui-form" action="<?php echo e(url('searchOrderById'), false); ?>" method="post">
                                    <?php echo e(csrf_field(), false); ?>

                                    <div class="layui-form-item">
                                        <label class="layui-form-label"><?php echo e(__('system.order_number'), false); ?></label>
                                        <div class="layui-input-block">
                                            <input type="text" name="order_id" required  lay-verify="required" placeholder="<?php echo e(__('prompt.set_order_number'), false); ?>" autocomplete="off" class="layui-input">
                                        </div>
                                    </div>
                                    <div class="layui-form-item">
                                        <div class="layui-input-block">
                                            <button class="layui-btn" lay-submit lay-filter="orderByid"><?php echo e(__('system.search_now'), false); ?></button>
                                            <button type="reset" class="layui-btn layui-btn-primary"><?php echo e(__('system.reset_order'), false); ?></button>
                                        </div>
                                    </div>
                                </form>

                            </div>

                            <!-- 邮箱查询 -->
                            <div class="layui-tab-item">
                                <form class="layui-form" action="<?php echo e(url('searchOrderByAccount'), false); ?>" method="post">
                                    <?php echo e(csrf_field(), false); ?>

                                    <div class="layui-form-item">
                                        <label class="layui-form-label"><?php echo e(__('system.email'), false); ?></label>
                                        <div class="layui-input-block">
                                            <input type="email" name="account" required  lay-verify="required" placeholder="<?php echo e(__('prompt.set_email'), false); ?>" autocomplete="off" class="layui-input">
                                        </div>
                                    </div>
                                    <?php if(config('webset.isopen_searchpwd') == 1): ?>
                                    <div class="layui-form-item">
                                        <label class="layui-form-label"><?php echo e(__('system.search_password'), false); ?></label>
                                        <div class="layui-input-block">
                                            <input type="password" name="search_pwd" required  lay-verify="required" placeholder="<?php echo e(__('prompt.get_search_password'), false); ?>" autocomplete="off" class="layui-input">
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <div class="layui-form-item">
                                        <div class="layui-input-block">
                                            <button class="layui-btn" lay-submit lay-filter="orderByAccount"><?php echo e(__('system.search_now'), false); ?></button>
                                            <button type="reset" class="layui-btn layui-btn-primary"><?php echo e(__('system.reset_order'), false); ?></button>
                                        </div>
                                    </div>

                                </form>
                            </div>

                            <!-- 浏览器缓存 -->
                            <div class="layui-tab-item">
                                <form class="layui-form" action="<?php echo e(url('searchOrderByBrowser'), false); ?>">
                                    <?php echo e(csrf_field(), false); ?>

                                    <div class="layui-form-item">
                                        <div class="layui-input-block">
                                            <button class="layui-btn" lay-submit lay-filter="searchOrderByBrowser">
                                                <?php echo e(__('system.search_now'), false); ?></button>
                                        </div>
                                    </div>
                                </form>


                            </div>

                        </div>
                    </div>

                </div>



            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('tpljs'); ?>
    <script>
        layui.use(['element', 'form'], function(){
            var element = layui.element;
            var form = layui.form;
            //监听提交
            form.on('submit(orderByid)', function(data){
                return true;
            });
            //监听提交
            form.on('submit(orderByAccount)', function(data){
                return true;
            });
            //监听提交
            form.on('submit(searchOrderByBrowser)', function(data){
                return true;
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layui.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpstudy_pro\WWW\evrstrceshi.cc\resources\views/layui/static_pages/searchOrder.blade.php ENDPATH**/ ?>