<?php $__env->startSection('notice'); ?>
    <?php echo $__env->make('hyper.layouts._notice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right d-none d-lg-block">
                <div class="app-search">
                    <div class="position-relative">
                        <input type="text" class="form-control" id="search_pc" placeholder="<?php echo e(__('hyper.home_search_box'), false); ?>">
                        <span class="mdi mdi-magnify"></span>
                    </div>
                </div>
            </div>
            
            <h4 class="page-title"><?php echo e(__('hyper.home_title'), false); ?></h4>
        </div>
    </div>
</div>
<?php $__env->startSection('notice'); ?>
<?php echo $__env->yieldSection(); ?>
<div class="row d-lg-none">
    <div class="col-12">
        <div class="app-search">
            <div class="position-relative">
                <input type="text" class="form-control" id="search_sj" placeholder="<?php echo e(__('hyper.home_search_box'), false); ?>">
                <span class="mdi mdi-magnify"></span>
            </div>
        </div>
    </div>
</div>
<div class="d-none d-md-block">
    <?php $__currentLoopData = $classifys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classify): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row category-pc">
        <div class="col-md-12">
            <h3>
                
                <span class="badge badge-info"><?php echo e($classify['name'], false); ?></span>
            </h3>
        </div>
        <div class="col-md-12">
            <div class="card pl-1 pr-1">
                <table class="table table-centered mb-0">
                    <thead>
                        <tr>
                            
                            <th width="40%"><?php echo e(__('hyper.home_product_name'), false); ?></th>
                            
                            <th width="10%"><?php echo e(__('hyper.home_product_class'), false); ?></th>
                            
                            <th width="10%"><?php echo e(__('hyper.home_in_stock'), false); ?></th>
                            
                            <th width="10%"><?php echo e(__('hyper.home_price'), false); ?></th>
                            
                            <th width="10%" class="text-center"><?php echo e(__('hyper.home_place_an_order'), false); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $classify['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="product-pc">
                            <td class="d-none"><?php echo e($classify['name'], false); ?>-<?php echo e($product['pd_name'], false); ?></td>
                            <td>
                                
                                <?php if($product['in_stock'] > 0): ?>
                                <a href="<?php echo e(url("/buy/{$product['id']}"), false); ?>" class="text-body"><?php echo e($product['pd_name'], false); ?></a>
                                <?php else: ?>
                                <div class="text-body" style="cursor: no-drop;"><?php echo e($product['pd_name'], false); ?></div>
                                <?php endif; ?>
                                <?php if($product['wholesale_price']): ?>
                                    
                                    <span class="badge badge-outline-warning"><?php echo e(__('hyper.home_discount'), false); ?></span>
                                   <?php endif; ?>
                            </td>
                            <td>
                                <?php if($product['pd_type'] == 1): ?>
                                    
                                    <span class="badge badge-outline-primary"><?php echo e(__('hyper.home_automatic_delivery'), false); ?></span>
                                <?php else: ?>
                                    
                                    <span class="badge badge-outline-danger"><?php echo e(__('hyper.home_charge'), false); ?></span>
                                <?php endif; ?>
                            </td>
                            
                            <td><?php echo e($product['in_stock'], false); ?></td>
                            
                            <td>￥<b><?php echo e($product['actual_price'], false); ?></b></td>
                            <td class="text-center">
                                <?php if($product['in_stock'] > 0): ?>
                                    
                                    <a class="btn btn-outline-primary" href="<?php echo e(url("/buy/{$product['id']}"), false); ?>"><?php echo e(__('hyper.home_buy'), false); ?></a>
                                <?php else: ?>
                                    
                                    <a class="btn btn-outline-secondary disabled" href="javascript:void(0);"><?php echo e(__('hyper.home_sell_out'), false); ?></a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="d-block d-md-none">
    <?php $__currentLoopData = $classifys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classify): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row category-sj">
        <div class="col-md-12">
            <h3>
                
                <span class="badge badge-info"><?php echo e($classify['name'], false); ?></span>
            </h3>
        </div>
        <?php $__currentLoopData = $classify['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 col-sm-6 product-sj">
            <span class="d-none"><?php echo e($classify['name'], false); ?>-<?php echo e($product['pd_name'], false); ?></span>
            <?php if($product['in_stock'] > 0): ?>
            <a class="box" href="<?php echo e(url("/buy/{$product['id']}"), false); ?>">
                <div class="card">
            <?php else: ?>
            <a class="box" href="javascript:void(0);">
                <div class="card border-danger border">
            <?php endif; ?>
                    <div class="card-body">
                        
                        <h4 class="card-title"><?php echo e($product['pd_name'], false); ?></h4>
                        <p>
                            <?php if($product['pd_type'] == 1): ?>
                                
                                <span class="badge badge-outline-primary"><?php echo e(__('hyper.home_automatic_delivery'), false); ?></span>
                            <?php else: ?>
                                
                                <span class="badge badge-outline-danger"><?php echo e(__('hyper.home_charge'), false); ?></span>
                            <?php endif; ?>
                            <?php if($product['wholesale_price']): ?>
                                
                                <span class="badge badge-outline-warning"><?php echo e(__('hyper.home_discount'), false); ?></span>
                            <?php endif; ?>
                        </p>
                        
                        <div class="float-right"><?php echo e(__('hyper.home_in_stock'), false); ?>(<?php echo e($product['in_stock'], false); ?>)</div>
                        <p class="card-text">
                            
                        	<span>￥<b><?php echo e($product['actual_price'], false); ?></b><span>
                        </p>
                    </div>
                </div>
            </a>
        </div> <!-- end col -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div> <!-- end row-->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<script src="/assets/style/js/jquery-3.4.1.min.js"></script>
<script>
    $("#search_pc").on("input",function(e){
        var txt_pc = $("#search_pc").val();
        if($.trim(txt_pc)!="") {
            $(".category-pc").hide().filter(":contains('"+txt_pc+"')").show();
            $(".product-pc").hide().filter(":contains('"+txt_pc+"')").show();
        } else {
            $(".category-pc").show();
            $(".product-pc").show();
        }
    });
    $("#search_sj").on("input",function(e){
        var txt_sj = $("#search_sj").val();
        if($.trim(txt_sj)!="") {
            $(".category-sj").hide().filter(":contains('"+txt_sj+"')").show();
            $(".product-sj").hide().filter(":contains('"+txt_sj+"')").show();
        } else {
            $(".category-sj").show();
            $(".product-sj").show();
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('hyper.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpstudy_pro\WWW\evrstrceshi.cc\resources\views/hyper/static_pages/home.blade.php ENDPATH**/ ?>