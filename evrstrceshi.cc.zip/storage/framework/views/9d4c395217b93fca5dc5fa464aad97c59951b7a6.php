<div class="notice layui-hide-xs">
    <p class="tit"><?php echo e(__('system.announcement'), false); ?>:</p>
    <div class="tips"><?php echo config('webset.notice'); ?></div>
</div>
<?php /**PATH D:\phpstudy_pro\WWW\evrstrceshi.cc\resources\views/luna/layouts/_notice.blade.php ENDPATH**/ ?>