<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title><?php echo e(config('webset.title'), false); ?></title>
    <meta name="Keywords" content="<?php echo e(config('webset.keywords'), false); ?>">
    <meta name="Description" content="<?php echo e(config('webset.description'), false); ?>">
    <link rel="stylesheet" href="/assets/layui/css/layui.css">
    <link rel="stylesheet" href="/assets/luna/main.css">
    <link rel="shortcut icon" href="/assets/style/favicon.ico" />
    <?php if(\request()->server()['REQUEST_SCHEME'] == "https"): ?>
        <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <?php endif; ?>
</head>
<?php /**PATH D:\phpstudy_pro\WWW\evrstrceshi.cc\resources\views/luna/layouts/_header.blade.php ENDPATH**/ ?>