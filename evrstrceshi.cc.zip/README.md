# 海马平台
海马网络验证，集成网络验证+发卡


- 框架来自：[laravel/framework](https://github.com/laravel/laravel).
- 后台管理系统：[laravel-admin](https://laravel-admin.org/).
- 基于[独角数卡](https://github.com/assimon/dujiaoka).修改

